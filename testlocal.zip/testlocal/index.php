<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h2>Formular uploade file</h2>
  <form action="https://testlocal.com/post.php" method="post" enctype="multipart/form-data">
	<div class="form-group">
      <label for="nume">Nume:</label>
      <input type="text" class="form-control" id="nume" placeholder="Introduceti numele" name="nume">
    </div>
	<div class="form-group">
      <label for="prenume">Preume:</label>
      <input type="text" class="form-control" id="prenume" placeholder="Introduceti prenumele" name="prenume">
    </div>
	<div class="form-group">
      <label for="email">Email:</label>
      <input type="email" class="form-control" id="email" placeholder="Introduceti adresa de email" name="email">
    </div>
    <div class="form-group">
      <label for="poza">Poza:</label>
      <input type="file" class="form-control" id="poza" placeholder="Selectaati poza dorita" name="poza">
    </div>
    <button type="submit" class="btn btn-default">Trimite datele</button>
  </form>
</div>

</body>
</html>
