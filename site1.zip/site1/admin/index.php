<?php
echo "sunt in admin";
?>