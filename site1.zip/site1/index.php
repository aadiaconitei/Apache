<?php 

echo " Salut site 1";
?>